package com.counterC.counterC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CounterCApplication {
	public static void main(String[] args) {
		SpringApplication.run(CounterCApplication.class, args);
	}

}
