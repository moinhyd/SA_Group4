package com.counterC.counterC.receiver;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

@Component
public class Receiver {

    private static List<String> emails = new ArrayList<>();
    static {
        emails.add("abc@gmail.com");
        emails.add("def@gmail.com");
        emails.add("ghi@gmail.com");
        emails.add("jkl@gmail.com");
        emails.add("mno@gmail.com");
        emails.add("pqr@gmail.com");
    }

    private CountDownLatch latch = new CountDownLatch(1);

    public void receiveMessage(byte[] message) {
        System.out.println(new String(message));
        System.out.println("Sending email to : "+ emails.toString());
        latch.countDown();
    }
    public void receiveMessage(String message) {
        System.out.println(new String(message));
        latch.countDown();
    }

    public CountDownLatch getLatch() {
        return latch;
    }

}